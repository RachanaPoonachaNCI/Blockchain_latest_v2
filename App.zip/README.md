- Install metamask extension
- Clone the project
- Install dependencies
  
      npm i
      npm start
